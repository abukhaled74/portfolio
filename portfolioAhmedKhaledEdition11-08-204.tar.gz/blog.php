<section
	class="elementor-section elementor-top-section elementor-element elementor-element-2baaf94 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
	data-id="2baaf94" data-element_type="section">
	<div class="elementor-container elementor-column-gap-default">
		<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-e6200bb"
			data-id="e6200bb" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
				<div class="elementor-element elementor-element-3148a7f elementor-widget elementor-widget-ryancv-blog"
					data-id="3148a7f" data-element_type="widget"
					data-widget_type="ryancv-blog.default">
					<div class="elementor-widget-container"> <!-- Blog -->
						<div class="content works blog-grid blog"> <!-- title -->
							<div class="title"> <span>Blog</span></div> <!-- filters -->
							<div class="filter-menu filter-button-group">
								<div class="f_btn active"> <label><input type="radio"
											name="fl_radio" value=".grid-item" />All</label>
								</div>
								<div class="f_btn"> <label><input type="radio"
											name="fl_radio" data-cat-id="17"
											value=".bf-music" />Music</label></div>
								<div class="f_btn"> <label><input type="radio"
											name="fl_radio" data-cat-id="16"
											value=".bf-design" />Design</label></div>
								<div class="f_btn"> <label><input type="radio"
											name="fl_radio" data-cat-id="34"
											value=".bf-code" />Code</label></div>
							</div> <!-- content -->
							<div class="row grid-items border-line-v"> <!-- blog item -->
								<div
									class="col col-d-6 col-t-6 col-m-12 grid-item bf-code ">
									<div class="box-item">
										<div id="post-98"
											class="post-98 post type-post status-publish format-standard has-post-thumbnail hentry category-code tag-code tag-html tag-plugin tag-wordpress">
											<div class="image"> <a
													href="developer/2020/04/28/by-spite-about-do-of-allow.html">
													<div class="post-thumbnail">
														<noscript><img width="800"
																height="375"
																src="developer/wp-content/uploads/sites/3/2020/04/blog2.jpg"
																class="attachment-post-thumbnail size-post-thumbnail wp-post-image"
																alt="" decoding="async"
																srcset="developer/wp-content/uploads/sites/3/2020/04/blog2.jpg 800w, developer/wp-content/uploads/sites/3/2020/04/blog2-300x141.jpg 300w, developer/wp-content/uploads/sites/3/2020/04/blog2-768x360.jpg 768w, developer/wp-content/uploads/sites/3/2020/04/blog2-184x86.jpg 184w"
																sizes="(max-width: 800px) 100vw, 800px" /></noscript><img
															width="800" height="375"
															src='data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%20800%20375%22%3E%3C/svg%3E'
															data-src="developer/wp-content/uploads/sites/3/2020/04/blog2.jpg"
															class="lazyload attachment-post-thumbnail size-post-thumbnail wp-post-image"
															alt="" decoding="async"
															data-srcset="developer/wp-content/uploads/sites/3/2020/04/blog2.jpg 800w, developer/wp-content/uploads/sites/3/2020/04/blog2-300x141.jpg 300w, developer/wp-content/uploads/sites/3/2020/04/blog2-768x360.jpg 768w, developer/wp-content/uploads/sites/3/2020/04/blog2-184x86.jpg 184w"
															data-sizes="(max-width: 800px) 100vw, 800px" />
													</div><!-- .post-thumbnail -->
												</a></div>
											<div class="desc"> <a
													href="developer/2020/04/28/by-spite-about-do-of-allow.html">
													<span class="date"> April 28, 2020
													</span> </a> <a
													href="developer/2020/04/28/by-spite-about-do-of-allow.html"
													class="name">By spite about do of
													allow</a>
												<div class="text">
													<p>Ex audire suavitate has, ei quodsi
														tacimates sapientem sed, pri zril
														ubique ut. Te cule tation munere
														noluisse. Enim torquatos&#8230;</p>
												</div>
											</div>
										</div>
									</div>
								</div> <!-- blog item -->
								<div
									class="col col-d-6 col-t-6 col-m-12 grid-item bf-design ">
									<div class="box-item">
										<div id="post-96"
											class="post-96 post type-post status-publish format-standard has-post-thumbnail hentry category-design tag-code tag-html tag-plugin tag-wordpress">
											<div class="image"> <a
													href="developer/2020/04/28/a-song-and-dance-act.html">
													<div class="post-thumbnail">
														<noscript><img width="1000"
																height="680"
																src="developer/wp-content/uploads/sites/3/2020/04/bg.jpg"
																class="attachment-post-thumbnail size-post-thumbnail wp-post-image"
																alt="" decoding="async"
																srcset="developer/wp-content/uploads/sites/3/2020/04/bg.jpg 1000w, developer/wp-content/uploads/sites/3/2020/04/bg-300x204.jpg 300w, developer/wp-content/uploads/sites/3/2020/04/bg-768x522.jpg 768w, developer/wp-content/uploads/sites/3/2020/04/bg-184x125.jpg 184w"
																sizes="(max-width: 1000px) 100vw, 1000px" /></noscript><img
															width="1000" height="680"
															src='data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%201000%20680%22%3E%3C/svg%3E'
															data-src="developer/wp-content/uploads/sites/3/2020/04/bg.jpg"
															class="lazyload attachment-post-thumbnail size-post-thumbnail wp-post-image"
															alt="" decoding="async"
															data-srcset="developer/wp-content/uploads/sites/3/2020/04/bg.jpg 1000w, developer/wp-content/uploads/sites/3/2020/04/bg-300x204.jpg 300w, developer/wp-content/uploads/sites/3/2020/04/bg-768x522.jpg 768w, developer/wp-content/uploads/sites/3/2020/04/bg-184x125.jpg 184w"
															data-sizes="(max-width: 1000px) 100vw, 1000px" />
													</div><!-- .post-thumbnail -->
												</a></div>
											<div class="desc"> <a
													href="developer/2020/04/28/a-song-and-dance-act.html">
													<span class="date"> April 28, 2020
													</span> </a> <a
													href="developer/2020/04/28/a-song-and-dance-act.html"
													class="name">A Song And Dance Act</a>
												<div class="text">
													<p>Ex audire suavitate has, ei quodsi
														tacimates sapientem sed, pri zril
														ubique ut. Te cule tation munere
														noluisse. Enim torquatos&#8230;</p>
												</div>
											</div>
										</div>
									</div>
								</div> <!-- blog item -->
								<div
									class="col col-d-6 col-t-6 col-m-12 grid-item bf-music ">
									<div class="box-item">
										<div id="post-94"
											class="post-94 post type-post status-publish format-standard has-post-thumbnail hentry category-music tag-code tag-html tag-plugin tag-wordpress">
											<div class="image"> <a
													href="developer/2020/04/28/music-player-design.html">
													<div class="post-thumbnail">
														<noscript><img width="800"
																height="375"
																src="developer/wp-content/uploads/sites/3/2020/04/blog3.jpg"
																class="attachment-post-thumbnail size-post-thumbnail wp-post-image"
																alt="" decoding="async"
																srcset="developer/wp-content/uploads/sites/3/2020/04/blog3.jpg 800w, developer/wp-content/uploads/sites/3/2020/04/blog3-300x141.jpg 300w, developer/wp-content/uploads/sites/3/2020/04/blog3-768x360.jpg 768w, developer/wp-content/uploads/sites/3/2020/04/blog3-184x86.jpg 184w"
																sizes="(max-width: 800px) 100vw, 800px" /></noscript><img
															width="800" height="375"
															src='data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%20800%20375%22%3E%3C/svg%3E'
															data-src="developer/wp-content/uploads/sites/3/2020/04/blog3.jpg"
															class="lazyload attachment-post-thumbnail size-post-thumbnail wp-post-image"
															alt="" decoding="async"
															data-srcset="developer/wp-content/uploads/sites/3/2020/04/blog3.jpg 800w, developer/wp-content/uploads/sites/3/2020/04/blog3-300x141.jpg 300w, developer/wp-content/uploads/sites/3/2020/04/blog3-768x360.jpg 768w, developer/wp-content/uploads/sites/3/2020/04/blog3-184x86.jpg 184w"
															data-sizes="(max-width: 800px) 100vw, 800px" />
													</div><!-- .post-thumbnail -->
												</a></div>
											<div class="desc"> <a
													href="developer/2020/04/28/music-player-design.html">
													<span class="date"> April 28, 2020
													</span> </a> <a
													href="developer/2020/04/28/music-player-design.html"
													class="name">Music Player Design</a>
												<div class="text">
													<p>Ex audire suavitate has, ei quodsi
														tacimates sapientem sed, pri zril
														ubique ut. Te cule tation munere
														noluisse. Enim torquatos&#8230;</p>
												</div>
											</div>
										</div>
									</div>
								</div> <!-- blog item -->
								<div
									class="col col-d-6 col-t-6 col-m-12 grid-item bf-design bf-music ">
									<div class="box-item">
										<div id="post-92"
											class="post-92 post type-post status-publish format-standard has-post-thumbnail hentry category-design category-music tag-code tag-html tag-plugin tag-wordpress">
											<div class="image"> <a
													href="developer/2020/04/28/designing-the-perfect.html">
													<div class="post-thumbnail">
														<noscript><img width="800"
																height="375"
																src="developer/wp-content/uploads/sites/3/2020/04/blog1.jpg"
																class="attachment-post-thumbnail size-post-thumbnail wp-post-image"
																alt="" decoding="async"
																srcset="developer/wp-content/uploads/sites/3/2020/04/blog1.jpg 800w, developer/wp-content/uploads/sites/3/2020/04/blog1-300x141.jpg 300w, developer/wp-content/uploads/sites/3/2020/04/blog1-768x360.jpg 768w, developer/wp-content/uploads/sites/3/2020/04/blog1-184x86.jpg 184w"
																sizes="(max-width: 800px) 100vw, 800px" /></noscript><img
															width="800" height="375"
															src='data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%20800%20375%22%3E%3C/svg%3E'
															data-src="developer/wp-content/uploads/sites/3/2020/04/blog1.jpg"
															class="lazyload attachment-post-thumbnail size-post-thumbnail wp-post-image"
															alt="" decoding="async"
															data-srcset="developer/wp-content/uploads/sites/3/2020/04/blog1.jpg 800w, developer/wp-content/uploads/sites/3/2020/04/blog1-300x141.jpg 300w, developer/wp-content/uploads/sites/3/2020/04/blog1-768x360.jpg 768w, developer/wp-content/uploads/sites/3/2020/04/blog1-184x86.jpg 184w"
															data-sizes="(max-width: 800px) 100vw, 800px" />
													</div><!-- .post-thumbnail -->
												</a></div>
											<div class="desc"> <a
													href="developer/2020/04/28/designing-the-perfect.html">
													<span class="date"> April 28, 2020
													</span> </a> <a
													href="developer/2020/04/28/designing-the-perfect.html"
													class="name">Designing the perfect</a>
												<div class="text">
													<p>Ex audire suavitate has, ei quodsi
														tacimates sapientem sed, pri zril
														ubique ut. Te cule tation munere
														noluisse. Enim torquatos&#8230;</p>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="clear"></div>
							</div>
							<div class="bts bts-center"> <a class="lnk button load-more"
									href="#">Load More</a></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>